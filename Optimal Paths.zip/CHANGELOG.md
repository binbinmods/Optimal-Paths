# 1.1.1

Updated to allow for the Failed Expedition (Blood Blob) node to always spawn in non-highscore mode.

# 1.1.0

Updated to include non-highscoring variant. Highscoring only will be shifted to the highscoring modpack

# 1.0.0

Updated for v1.5.0. Still haven't included path highlighting just yet.

# 0.9.1

Fixed erroneous dependency. Mod should only require BepInEx.

# 0.9.0

Pre-release version.